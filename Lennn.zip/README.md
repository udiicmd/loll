***Call-to-Action (CTA)***
  • 🎭 Source Made By : ZeroX / Zerozingod
  • 🎭 YouTube : https://youtube.com/@zerozingod
  • 🎭 WhatsApp : https://wa.me/6288216153331
  • 🎭 Saluran : https://whatsapp.com/channel/0029VavpPJQJENxrzZ5UCD0h
  
# N O T E
Mengakui barang yang bukan haknya dapat dianggap sebagai perbuatan yang tidak etis dan melanggar hukum. Dalam Islam, perbuatan ini disebut "dusta" atau "kedustaan" dan termasuk dalam kategori dosa besar.

Dalam Al-Qur'an, Allah SWT berfirman:

Ayat Al-Qur'an
1. "Dan janganlah kamu mengatakan terhadap apa yang dikatakan oleh lidahmu dengan dusta: 'Ini halal dan ini haram' untuk mengada-adakan kebohongan terhadap Allah. Sesungguhnya orang-orang yang mengada-adakan kebohongan terhadap Allah tidak akan beruntung." (QS. An-Nahl: 116)
2. "Hai orang-orang yang beriman, mengapa kamu mengatakan apa yang tidak kamu perbuat? Sangatlah besar kebencian di sisi Allah bahwa kamu mengatakan apa yang tidak kamu perbuat." (QS. Ash-Shaff: 2-3)

Konsekuensi
1. Dosa besar di sisi Allah Swt.
2. Kehilangan kepercayaan orang lain.
3. Kerugian moral dan spiritual.
4. Kemungkinan hukuman pidana (tergantung hukum yang berlaku).

Jika Anda telah melakukan kesalahan ini, segera:

1. Mengakui kesalahan kepada Allah Swt.
2. Meminta maaf kepada pihak yang terkena dampak.
3. Mengembalikan barang jika memungkinkan.
4. Berusaha untuk tidak mengulangi kesalahan tersebut.

Sumber:

1. Al-Qur'an dan Tafsirnya.
2. Hadits Shahih Bukhari dan Muslim.
3. Kitab Fiqh (seperti Fiqh Sunnah, Fiqh Hanafi, dll.).
4. Buku-buku akhlak dan moralitas Islam.